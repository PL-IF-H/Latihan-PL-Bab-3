package Tugas3;

import java.util.Scanner;

public class Program {

    Scanner input = new Scanner(System.in);
    String id, nama, tanggal;
    String data[][] = {{"Hitam Metalik", "3000", "001"}, {"Coklat Metalik", "2700", "002"}, {"Coklat Bercorak", "2300", "003"}, {"Hitam Bercorak", "2500", "004"}, {"Emas", "5000", "005"}, {"Perak", "4000", "006"}};
    int keliling;
    double diskon, harga;

    public Program(String a, String b, String c) { //overloading constructor
        this.id = a;
        this.nama = b;
        this.tanggal = c;
    }

    public Program() { //overloading constructor
        System.out.print("Masukkan kode bingkai sesuai pada daftar    : ");
        int kode = input.nextInt();
        for (int a = 0; a < data[0].length; a++) {
            if (kode == Integer.parseInt(data[a][2])) {
                System.out.println("Anda memesan bingkai berwarna " + data[a][0]);
            }
        }
        System.out.print("Masukkan panjang bingkai (cm): ");
        int panjang = input.nextInt();
        System.out.print("Masukkan lebar bingkai   (cm): ");
        int lebar = input.nextInt();
        setKeliling(panjang, lebar);
        hitung(kode);
        if (kode == 001 || kode == 005 || kode == 006) {
            if (harga > 300000 && harga <= 450000) {
                diskon = 0.05;
            } else if (harga > 450000 && harga <= 600000) {
                diskon = 0.1;
            } else if (harga > 600000) {
                diskon = 0.15;
            }
            hitung(diskon);
        }
        System.out.println("Total harga                  : " + harga);
    }

    private void setKeliling(int panjang, int lebar) {
        this.keliling = 2 * (panjang + lebar);
    }

    private void hitung(int kode) { //overloading method
        this.harga = keliling * Integer.parseInt(data[kode - 1][1]);
    }

    private void hitung(double diskon) { //overloading method
        this.harga = harga * (1 - diskon);
    }

    public void tampil() {
        System.out.println("==================== Daftar Barang ======================");
        System.out.println("Kode | Warna Bingkai            | Harga Bingkai per Meter");
        for (int a = 0; a < data.length; a++) {
            int spasi = "Warna Bingkai            ".length() - data[a][0].length();
            System.out.println(data[a][2] + "  | " + data[a][0] + rapih(spasi) + "| " + data[a][1]);
        }
        System.out.println("---------------------------------------------------------");
    }

    private String rapih(int a) { // hanya untuk merapihkan tabel
        String spasi = " ";
        for (int i = 1; i < a; i++) {
            spasi = spasi.concat(" ");
        }
        return spasi;
    }

}
