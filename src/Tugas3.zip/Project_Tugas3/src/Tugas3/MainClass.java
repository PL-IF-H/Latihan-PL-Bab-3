package Tugas3;

import java.util.Scanner;

public class MainClass {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Scanner inputLn = new Scanner(System.in);
        Program[] User = new Program[100];
        System.out.println("========= Program Penghitung Pesanan Pembuatan ==========");

        for (int i = 0; i < User.length; i++) {
            System.out.println("=====================> Pembeli no-" + (i + 1) + " <====================");
            System.out.print("Masukkan ID pembelian         : ");
            String id = input.next();
            System.out.print("Masukkan nama pembeli         : ");
            String nama = inputLn.nextLine();
            System.out.print("Masukkan tanggal pembelian    : ");
            String tanggal = inputLn.nextLine();
            User[i] = new Program(id, nama, tanggal);
            User[i].tampil();
            User[i] = new Program();
        }
    }
}
